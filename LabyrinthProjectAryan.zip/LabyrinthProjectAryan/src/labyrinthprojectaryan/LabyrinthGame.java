/*
package labyrinthprojectaryan;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

public class LabyrinthGame extends JFrame {
    private static final int SIZE = 30;
    private static final int CELL_SIZE = 20;
    private static final int DRAGON_SIZE = 5;

    private int playerX, playerY;
    private int dragonX, dragonY;
    private boolean[][] obstacles;
    private int winCount = 0;
    private String playerName;
    private boolean nameObtained = false;
    private int elapsedTimeInSeconds;
    
    public int getWinCount() {
        return winCount;
    }

    public void setWinCount(int winCount) {
        this.winCount = winCount;
    }

    public LabyrinthGame() {
        setTitle("Labyrinth Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initializeGame();
        if (!nameObtained) {
            obtainPlayerName();
            nameObtained = true;
        }

        addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {}

            @Override
            public void keyPressed(KeyEvent e) {
                movePlayer(e.getKeyCode());
                checkCollision();
                repaint();
            }

            @Override
            public void keyReleased(KeyEvent e) {}
        });

        elapsedTimeInSeconds = 0;
        setFocusable(true);
        Timer timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                elapsedTimeInSeconds++;
                moveDragon();
                checkCollision();
                repaint();
            }
        });
        timer.start();
        
        JMenu menu = new JMenu("Game");
        JMenuItem leaderboardItem = new JMenuItem("Display Leaderboard");
        leaderboardItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayLeaderboard();
            }
        });
        menu.add(leaderboardItem);
        
        JMenuItem newGameItem = new JMenuItem("New Game");
        newGameItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startNewGame();
            }
        });
        menu.add(newGameItem);

        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        menu.add(exitItem);
        
        JMenuBar menuBar = new JMenuBar();
        menuBar.add(menu);
        setJMenuBar(menuBar);

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                drawGrid(g);
                drawObstacles(g);
                drawPlayer(g);
                drawDragon(g);
                drawElapsedTime(g);
                drawExit(g);
                g.setColor(Color.BLACK);
                g.drawString(playerName + "'s Wins: " + getWinCount(), 5, getSize().height - 585);
            }
        };

        add(panel);
        int dynamicWidth = (SIZE + 1) * CELL_SIZE;  // Adjust as needed
        int dynamicHeight = (SIZE + 3) * CELL_SIZE; // Adjust as needed
        setPreferredSize(new Dimension(dynamicWidth, dynamicHeight));
        pack();
        setLocationRelativeTo(null);
    }
    
    private void displayLeaderboard() {
        LeaderboardManager.displayLeaderboard();
    }

    private void obtainPlayerName() {
        playerName = JOptionPane.showInputDialog(this, "Enter your name:");
        if (playerName == null || playerName.trim().isEmpty()) {
            playerName = "Player";
        }
    }
    
    private void startNewGame() {
        obtainPlayerName();
        initializeGame();
        winCount = 0;
        elapsedTimeInSeconds = 0;
        repaint();
    }

    private void initializeGame() {
        playerX = 0;
        playerY = SIZE - 1;

        Random random = new Random();
        dragonX = random.nextInt(SIZE);
        dragonY = random.nextInt(SIZE);

        generateObstacles();
    }

    private void generateObstacles() {
        obstacles = new boolean[SIZE][SIZE];
        Random random = new Random();

        for (int i = 0; i < SIZE * 8; i++) {
            int obstacleX = random.nextInt(SIZE);
            int obstacleY = random.nextInt(SIZE);

            if (!(obstacleX >= SIZE - 4 && obstacleY < 4) &&
                    !(obstacleX < 4 && obstacleY >= SIZE - 4) &&
                    !(obstacleX == SIZE - 1 && obstacleY == 0) &&
                    !(obstacleX == playerX && obstacleY == playerY)) {
                obstacles[obstacleX][obstacleY] = true;
            }
        }
    }

    private void movePlayer(int keyCode) {
        switch (keyCode) {
            case KeyEvent.VK_LEFT:
                if (playerX > 0 && !obstacles[playerX - 1][playerY]) playerX--;
                break;
            case KeyEvent.VK_RIGHT:
                if (playerX < SIZE - 1 && !obstacles[playerX + 1][playerY]) playerX++;
                break;
            case KeyEvent.VK_UP:
                if (playerY > 0 && !obstacles[playerX][playerY - 1]) playerY--;
                break;
            case KeyEvent.VK_DOWN:
                if (playerY < SIZE - 1 && !obstacles[playerX][playerY + 1]) playerY++;
                break;
        }
    }

    private void moveDragon() {
        Random random = new Random();
        int direction = random.nextInt(4);

        switch (direction) {
            case 0:
                if (dragonX > 0 && !obstacles[dragonX - 1][dragonY]) dragonX--;
                break;
            case 1:
                if (dragonX < SIZE - DRAGON_SIZE && !obstacles[dragonX + 1][dragonY]) dragonX++;
                break;
            case 2:
                if (dragonY > 0 && !obstacles[dragonX][dragonY - 1]) dragonY--;
                break;
            case 3:
                if (dragonY < SIZE - DRAGON_SIZE && !obstacles[dragonX][dragonY + 1]) dragonY++;
                break;
        }
    }

    private void checkCollision() {
        int playerRight = playerX + 1;
        int playerBottom = playerY + 1;
        int dragonRight = dragonX + DRAGON_SIZE;
        int dragonBottom = dragonY + DRAGON_SIZE;

        if (playerX < dragonRight && playerRight > dragonX && playerY < dragonBottom && playerBottom > dragonY) {
            LeaderboardManager.addToLeaderboard(playerName, winCount);
            initializeGame();
            elapsedTimeInSeconds = 0;
            winCount = 0;
            
        } else if (playerX == SIZE - 1 && playerY == 0) {
            initializeGame();
            elapsedTimeInSeconds = 0;
            winCount++;
        }
    }

    private void drawElapsedTime(Graphics g) {
        g.setColor(Color.BLACK);
        g.drawString("Time: " + elapsedTimeInSeconds + " seconds", 500, getSize().height - 75);
    }

    private void drawGrid(Graphics g) {
        int startCol = Math.max(0, playerX - 1);
        int endCol = Math.min(SIZE - 1, playerX + 1);

        int startRow = Math.max(0, playerY - 1);
        int endRow = Math.min(SIZE - 1, playerY + 1);

        for (int i = startCol; i <= endCol; i++) {
            for (int j = startRow; j <= endRow; j++) {
                int x = i * CELL_SIZE;
                int y = j * CELL_SIZE;
                g.setColor(Color.LIGHT_GRAY);
                g.drawRect(x, y, CELL_SIZE, CELL_SIZE);
            }
        }
    }

    private void drawObstacles(Graphics g) {
        int startCol = Math.max(0, playerX - 1);
        int endCol = Math.min(SIZE - 1, playerX + 1);

        int startRow = Math.max(0, playerY - 1);
        int endRow = Math.min(SIZE - 1, playerY + 1);

        g.setColor(Color.pink);
        for (int i = startCol; i <= endCol; i++) {
            for (int j = startRow; j <= endRow; j++) {
                if (obstacles[i][j]) {
                    int x = i * CELL_SIZE;
                    int y = j * CELL_SIZE;
                    g.fillRect(x, y, CELL_SIZE, CELL_SIZE);
                }
            }
        }
    }

    private void drawPlayer(Graphics g) {
        g.setColor(Color.GREEN);
        g.fillRect(playerX * CELL_SIZE, playerY * CELL_SIZE, CELL_SIZE, CELL_SIZE);
    }

    private void drawDragon(Graphics g) {
        g.setColor(Color.RED);
        g.fillRect(dragonX * CELL_SIZE, dragonY * CELL_SIZE, CELL_SIZE * DRAGON_SIZE, CELL_SIZE * DRAGON_SIZE);
    }

    private void drawExit(Graphics g) {
        g.setColor(Color.BLACK);
        g.fillRect((SIZE - 1) * CELL_SIZE, 0, CELL_SIZE, CELL_SIZE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LabyrinthGame game = new LabyrinthGame();
            game.setVisible(true);
        });
    }
}
*/