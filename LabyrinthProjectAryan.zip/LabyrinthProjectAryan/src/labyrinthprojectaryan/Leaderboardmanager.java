package labyrinthprojectaryan;
import java.sql.*;

public class Leaderboardmanager {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/labyrinth";
    private static final String USER = "root";
    private static final String PASSWORD = "123QWEasd";

    public static void addToLeaderboard(String playerName, int winCount) {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD)) {
            String query = "INSERT INTO leaderboard (player_name, win_count) VALUES (?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, playerName);
                preparedStatement.setInt(2, winCount);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
        }
    }

    public static void displayLeaderboard() {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD)) {
            String query = "SELECT * FROM leaderboard ORDER BY win_count DESC";
            try (Statement statement = connection.createStatement()) {
                try (ResultSet resultSet = statement.executeQuery(query)) {

                    System.out.println("Leaderboard:");
                    System.out.printf("%-20s %s%n", "Player Name", "Win Count");
                    System.out.println("------------------------------");
                    while (resultSet.next()) {
                        String playerName = resultSet.getString("player_name");
                        int winCount = resultSet.getInt("win_count");
                        System.out.printf("%-24s %d%n", playerName, winCount);
                    }
                    System.out.println("------------------------------");
                }
            }
        } catch (SQLException e) {
        }
    }

}